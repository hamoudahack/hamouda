![katoolin](https://cloud.githubusercontent.com/assets/8742190/9415562/83397aae-4840-11e5-8f72-28dfffcc70a9.png)
# katoolin
Automatically install all Kali linux tools

# Features
- Add Kali linux repositories
- Remove kali linux repositories
- Install Kali linux tools

# Requirements
- Python 2.7
- An operating system (tested on Ubuntu)

# Instalation
- sudo su
- git clone https://github.com/LionSec/katoolin.git && cp katoolin/katoolin.py /usr/bin/katoolin
- chmod +x /usr/bin/katoolin
- sudo katoolin 

#Video
https://www.youtube.com/watch?v=8VxCWVoZEEE

#Usage
- Just select the number of a tool to install it
- Press 0 to install all tools
- back : Go back
- gohome : Go to the main menu

#I have some questions!

Please visit https://github.com/LionSec/wifresti/issues

#Donate
- Paypal : informatica98es@gmail.com
- skrill : informatica98es@gmail.com


#Contact

- Website : http://lionsec.net
- Youtube : https://youtube.com/inf98es
- Facebook : https://facebook.com/in98
- Twitter: @LionSec1
- Email : ledonman@gmail.com


